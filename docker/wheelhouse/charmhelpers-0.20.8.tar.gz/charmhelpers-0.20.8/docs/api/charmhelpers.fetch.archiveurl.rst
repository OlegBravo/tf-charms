charmhelpers.fetch.archiveurl module
====================================

.. automodule:: charmhelpers.fetch.archiveurl
    :members:
    :undoc-members:
    :show-inheritance: