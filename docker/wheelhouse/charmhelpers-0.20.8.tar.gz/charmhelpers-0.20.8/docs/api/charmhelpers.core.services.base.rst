charmhelpers.core.services.base
===============================

.. automembersummary::
    :nosignatures:

    ~charmhelpers.core.services.base

.. automodule:: charmhelpers.core.services.base
    :members:
    :undoc-members:
    :show-inheritance:
